# Matriz resumida de execucao

| Seq. | Microplano | Status | Dependencia principal |
|---:|---|---|---|
| 001 | Governanca, baseline e ADRs prioritarias | ⬜ Pendente | Documento mestre aprovado |
| 002 | Workspace Rust e toolchain | ⬜ Pendente | Microplano 001 concluido |
| 003 | CI cross-platform e qualidade | ⬜ Pendente | Microplano 002 concluido |
| 004 | Erros, tracing e saida da CLI | ⬜ Pendente | Microplano 002 concluido |
| 005 | Filesystem seguro e path safety | ⬜ Pendente | Microplanos 002 e 004 concluidos |
| 006 | Execucao segura de processos | ⬜ Pendente | Microplanos 002 e 004 concluidos |
| 007 | Contratos persistidos | ⬜ Pendente | Microplanos 002, 004 e 005 concluidos |
| 008 | Configuracao e migrations | ⬜ Pendente | Microplano 007 concluido |
| 009 | Inventario e empacotamento de assets | ⬜ Pendente | Microplanos 001 e 002 concluidos |
| 010 | Modelo canonico de capabilities | ⬜ Pendente | Microplano 009 concluido |
| 011 | Adapter Claude Code | ⬜ Pendente | Microplanos 005, 009 e 010 concluidos |
| 012 | Adapter Cursor | ⬜ Pendente | Microplanos 005, 009 e 010 concluidos |
| 013 | Adapter Codex | ⬜ Pendente | Microplanos 005, 009 e 010 concluidos |
| 014 | Adapter Antigravity | ⬜ Pendente | Microplanos 005, 009 e 010 concluidos |
| 015 | Pipeline de release nativo alpha | ⬜ Pendente | Microplano 003 concluido |
| 016 | Comando welcome | ⬜ Pendente | Microplanos 004 e 015 concluidos |
| 017 | Comando info | ⬜ Pendente | Microplanos 007 a 015 concluidos |
| 018 | Discover: deteccao brownfield | ⬜ Pendente | Microplanos 005, 007, 008 e 009 concluidos |
| 019 | Discover: instalacao do DARE | ⬜ Pendente | Microplanos 011 a 014 e 018 concluidos |
| 020 | Validate | ⬜ Pendente | Microplanos 004, 007 e 008 concluidos |
| 021 | Update: planejamento e manifest | ⬜ Pendente | Microplanos 008 a 014 concluidos |
| 022 | Update: aplicacao, backup e migrations | ⬜ Pendente | Microplano 021 concluido |
| 023 | Design deterministico | ⬜ Pendente | Microplanos 009, 010 e 019 concluidos |
| 024 | Fundacao de enrichment por IA | ⬜ Pendente | Microplanos 006 e 023 concluidos |
| 025 | Blueprint | ⬜ Pendente | Microplanos 020, 023 e 024 concluidos |
| 026 | DAG: parser, ranks e state store | ⬜ Pendente | Microplanos 005, 007 e 020 concluidos |
| 027 | DAG: visualizacao | ⬜ Pendente | Microplano 026 concluido |
| 028 | Execute: status, next e watch | ⬜ Pendente | Microplano 026 concluido |
| 029 | Execute: complete, fail, reset e Ralph inicial | ⬜ Pendente | Microplanos 006, 026 e 028 concluidos |
| 030 | Execute agent: mock, worktrees e budget | ⬜ Pendente | Microplanos 006, 029 e 034 planejado para preflight |
| 031 | Drivers reais de agentes | ⬜ Pendente | Microplanos 006, 024 e 030 concluidos |
| 032 | Review | ⬜ Pendente | Microplanos 024, 025 e 029 concluidos |
| 033 | Refine e sub-DAG | ⬜ Pendente | Microplanos 020, 026 e 032 concluidos |
| 034 | Guard | ⬜ Pendente | Microplanos 005 e 006 concluidos |
| 035 | Engine AST nativo | ⬜ Pendente | Microplanos 005 e 009 concluidos |
| 036 | Reverse | ⬜ Pendente | Microplanos 018, 024 e 035 concluidos |
| 037 | DNA | ⬜ Pendente | Microplanos 018, 024 e 035 concluidos |
| 038 | Patterns | ⬜ Pendente | Microplanos 035 e 037 concluidos |
| 039 | Migrate | ⬜ Pendente | Microplanos 024, 36, 37 e 38 concluidos |
| 040 | GraphRAG: storage e compatibilidade | ⬜ Pendente | Microplanos 005, 007 e 026 concluidos |
| 041 | GraphRAG: ingest, keyword, BFS e RRF | ⬜ Pendente | Microplanos 35 e 40 concluidos |
| 042 | GraphRAG semantico opcional | ⬜ Pendente | Microplano 041 concluido |
| 043 | GraphRAG avancado e Neo4j | ⬜ Pendente | Microplanos 040 a 042 concluidos |
| 044 | Skills registry: modelo e resolucao | ⬜ Pendente | Microplanos 005, 007 e 009 concluidos |
| 045 | Skills lifecycle e publish seguro | ⬜ Pendente | Microplano 044 concluido |
| 046 | Scaffolding: contratos, stacks e artefatos AX | ⬜ Pendente | Microplanos 007 a 10 e 22 concluidos |
| 047 | Init e bootstrap | ⬜ Pendente | Microplanos 011 a 15, 22 e 46 concluidos |
| 048 | Hooks e steering | ⬜ Pendente | Microplanos 005, 006 e 019 concluidos |
| 049 | Verificacao avancada e bench | ⬜ Pendente | Microplanos 029 a 34 concluidos |
| 050 | Comandos ai | ⬜ Pendente | Microplano 024 e drivers necessarios concluidos |
| 051 | Dashboard e REST compativel | ⬜ Pendente | Microplanos 017, 026, 40 e 49 concluidos |
| 052 | MCP real como transporte separado | ⬜ Pendente | Microplano 051 concluido |
| 053 | Self-update e package managers | ⬜ Pendente | Microplano 015 concluido |
| 054 | Hardening de paridade e seguranca | ⬜ Pendente | Todos os comandos planejados implementados |
| 055 | Pilotos, shadow tests e release candidate | ⬜ Pendente | Microplano 054 concluido |
| 056 | Cutover, stable e encerramento do legado | ⬜ Pendente | Microplano 055 concluido |